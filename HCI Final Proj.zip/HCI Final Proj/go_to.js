
const cards = document.querySelectorAll('.card');
const mainImage = document.querySelector('#main-image');


cards.forEach(card => {
  card.addEventListener('click', () => {
   
    cards.forEach(card => {
      card.classList.remove('active');
    });
    
   
    card.classList.add('active');
    
    
    const imageSrc = card.querySelector('img').getAttribute('src');
    mainImage.setAttribute('src', imageSrc);
  });
});